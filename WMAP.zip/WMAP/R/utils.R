utils::globalVariables(c("return.parm", "percentESS", "moments_b.ar",
                         "moreFeatures_b.v", "moments.ar", "otherFeatures.v",
                         "collatedMoments.ar", "collatedOtherFeatures.mt",
                         "collatedESS", "B", "method", "ESS", "output1"))
